const express = require('express');
const router = express.Router();
const Property = require('../models/Property');

// Create a new property
router.post('/add', async (req, res) => {
    try {
        const property = new Property(req.body);
        await property.save();
        res.status(201).json({ message: 'Property added successfully', property });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Get all properties
router.get('/', async (req, res) => {
    try {
        const properties = await Property.find();
        res.status(200).json(properties);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Get a specific property by ID
router.get('/:id', async (req, res) => {
    try {
        const property = await Property.findById(req.params.id);
        if (!property) return res.status(404).json({ message: 'Property not found' });
        res.status(200).json(property);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
