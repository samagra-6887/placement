#!/bin/bash

VERSION="v0.1.0"

show_version() {
  echo "sysopctl version $VERSION"
}

show_help() {
  cat << EOF
Usage: sysopctl [OPTION] [ARGUMENTS]

Basic Features:
  --help          Show this help message
  --version       Show the version of sysopctl

System Management Operations:
  service list    List all active services
  system load     View the current system load
  service start <service-name>   Start a service
  service stop <service-name>    Stop a service
  disk usage      Display disk usage statistics
  process monitor Monitor system processes
  logs analyze    Analyze system logs
  backup <path>   Backup system files

EOF
}

list_services() {
  systemctl list-units --type=service --state=active
}

view_system_load() {
  uptime
}

start_service() {
  sudo systemctl start "$1"
  echo "Service '$1' started."
}

stop_service() {
  sudo systemctl stop "$1"
  echo "Service '$1' stopped."
}

check_disk_usage() {
  df -h
}

monitor_processes() {
  top -n 1
}

analyze_logs() {
  journalctl -p err -n 20
}

backup_system_files() {
  if [ -z "$1" ]; then
    echo "Please provide a path to backup."
    return
  fi
  rsync -av --progress "$1" ~/backups/
  echo "Backup of $1 initiated."
}

if [ "$1" == "--help" ]; then
  show_help
elif [ "$1" == "--version" ]; then
  show_version
elif [ "$1" == "service" ]; then
  if [ "$2" == "list" ]; then
    list_services
  elif [ "$2" == "start" ]; then
    start_service "$3"
  elif [ "$2" == "stop" ]; then
    stop_service "$3"
  else
    echo "Invalid service command."
  fi
elif [ "$1" == "system" ] && [ "$2" == "load" ]; then
  view_system_load
elif [ "$1" == "disk" ] && [ "$2" == "usage" ]; then
  check_disk_usage
elif [ "$1" == "process" ] && [ "$2" == "monitor" ]; then
  monitor_processes
elif [ "$1" == "logs" ] && [ "$2" == "analyze" ]; then
  analyze_logs
elif [ "$1" == "backup" ]; then
  backup_system_files "$2"
else
  echo "Invalid command. Use '--help' for usage information."
fi
